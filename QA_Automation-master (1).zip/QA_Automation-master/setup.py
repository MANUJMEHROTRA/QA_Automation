from distutils.core import setup
import py2exe 
setup(console=["URL_QA_Python_D0331.py"])